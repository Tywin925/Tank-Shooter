// Fill out your copyright notice in the Description page of Project Settings.


#include "ToonTanksCreateClass.h"
#include "Kismet/GameplayStatics.h"
#include "Tank.h"
#include "Tower.h"
#include "ToonTanksPlayerController.h"

void AToonTanksCreateClass::ActorDied(AActor *DeadActor) {
    if (DeadActor == Tank) {
        Tank->handleDestruction();
        if(ToonTanksPlayerController) {
            ToonTanksPlayerController->setPlayerEnabledState(false);
        }
        GameOver(false);
    }
    else if (ATower* DestroyedTower = Cast<ATower>(DeadActor)) {
        DestroyedTower->handleDestruction();
        TargetTowers--;
        if (TargetTowers == 0) {
            GameOver(true);
        }
    }
}

void AToonTanksCreateClass::BeginPlay() {
    Super::BeginPlay();
    HandleGameStart();

}

void AToonTanksCreateClass::HandleGameStart() {
    TargetTowers = getTargetTowerCount();
    Tank = Cast<ATank>(UGameplayStatics::GetPlayerPawn(this, 0));
    ToonTanksPlayerController = Cast<AToonTanksPlayerController>(UGameplayStatics::GetPlayerController(this, 0));
    StartGame();
    if (ToonTanksPlayerController) {
        ToonTanksPlayerController->setPlayerEnabledState(false);
        FTimerHandle PlayerEnableTimerHandle;
        FTimerDelegate PlayerEnableTimerDelegate = FTimerDelegate::CreateUObject(
            ToonTanksPlayerController,
            &AToonTanksPlayerController::setPlayerEnabledState,
            true
        );
        GetWorldTimerManager().SetTimer(
            PlayerEnableTimerHandle,
            PlayerEnableTimerDelegate,
            startDelay,
            false
        );
    }
}

int32 AToonTanksCreateClass::getTargetTowerCount() {
    TArray<AActor*> Towers;
    UGameplayStatics::GetAllActorsOfClass(this, ATower::StaticClass(), Towers);
    return Towers.Num();
}
